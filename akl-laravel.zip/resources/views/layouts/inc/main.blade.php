<div class="col-lg-12 con1">
    <div class="contaainer-fluid">
        <div class="container">
            <img src="{{asset('assets/image/14.jpg')}}" class="rounded float-start img" alt="...">
            <h1>Welcome</h1>
            <h5 class="fw-lighter"> to my brakery</h5>
            <hr>
            <p><strong>GREEN TEA /</strong><label class="fst-italic">matcha latte</label></p>
            <p>
                Green tea is a type of tea that is made from Camellia sinensis leaves and buds that have not undergone the same withering and oxidation process used to make oolong teas and black teas.[1] Green tea originated in China, and since then its production and manufacture has spread to other countries in East and Southeast Asia.
            </p>

            <div class="row col-3">
                <button class="btn" style="width: 100%;">Order</button>
            </div>

        </div>
    </div>
</div>
<!--page2-->
<div class="col-lg-12 con2">
    <div class="contaainer-fluid">
        <div class="container">
            <img src="{{asset('assets/image/17.jpg')}}" class="rounded-pill float-end img1" alt="...">
            <label class="fs-1">r o s i e / </label>
            <label class="fst-italic">Blueberry soda cocktail</label>
            <hr>
            <p>
                shake shakes coffee milk tea milktea boba cute beige soft pastel tasty yummy drink food sweet starbucks milkshakes milky drinks latte ice tea iced tea iced drinks strawberry lemonade r o s i e
            </p>
            <br>
            <img src="{{asset('assets/image/17.1.jpg')}}" class="rounded-pill imgs" alt="...">
            <img src="{{asset('assets/image/17.4.jpg')}}" class="rounded-pill imgs" alt="...">
            <img src="{{asset('assets/image/17.3.jpg')}}" class="rounded-pill imgs" alt="...">
            <br>
            <div class="row col-12 " style="margin-top: 70px; width: 50%;">
                <button type="button" class="btn ">Order</button>
            </div>
        </div>
    </div>
</div>
<!--page3-->
<div class="col-lg-12 con3">
    <div class="contaainer-fluid">
        <div class="container">
            <img src="{{asset('assets/image/18.jpg')}}" class="rounded-3 " alt="..." style="width: 20%;">
            <img src="{{asset('assets/image/19.jpg')}}" class="rounded-3 " alt="..." style="width: 20%;">
            <img src="{{asset('assets/image/20.jpg')}}" class="rounded-3 " alt="..." style="width: 20%;">
            <br>
            <p class="fst-italic fw-lighter" style="margin: 10px;"> soft pastel cute sweet peach</p>
            <hr>
            <p>
                cafe coffee interior scenery lifestyle table style light beige latte milk tea dessert cream pastel korean japanese minimalistic clothing people natural pretty aesthetic grunge ethereal r o s i e
            </p>
            <h class="fs-2">" r o s i e "</h>
            <button type="button" class="btn float-end" style="width: 30%;">Order</button>
        </div>
    </div>
</div>
