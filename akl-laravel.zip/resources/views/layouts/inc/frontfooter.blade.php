<!-- Footer -->
<footer class="page-footer font-small unique-color-dark pt-4 " >
  
    <!-- Footer Elements -->
    <div class="container text-center">
  
      <!-- contact -->
      <div class="row row-cols-4 row-cols-lg-4 ">
          <div class="col">
              <div class="p-4 h4"><a class="fab fa-facebook-f link-info icon"></a></div>
          </div>
          <div class="col">
              <div class="p-4 h4"><a class="fab fa-instagram link-info icon"></a></div>
          </div>
          <div class="col">
              <div class="p-4 h4"><a class="fab fa-whatsapp link-info icon"></a></div>
          </div>
          <div class="col">
              <div class="p-4 h4"><a class="fab fa-tiktok link-info icon"></a></div>
          </div>
      </div>
      <!-- Call to action -->
  
    </div>
    <!-- Footer Elements -->
      <div class="container text-center">
        <hr>
      </div>
    <!-- Copyright -->
    <div class="footer-copyright text-center py-3">
        
        <p>© 2021 cw2/fns of noul,<a class="link-secondary" href="#">akl-bakery.com</a></p>
    </div>
    <!-- Copyright -->
  
  </footer>
  <!-- Footer -->